using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using POS_UI.Models;

namespace POS_UI.Services
{
    public interface IPOSApiService
    {
        Task<IEnumerable<Product>> GetProductsAsync();
        Task<Sale> CreateSaleAsync(Sale sale);
    }

    public class POSApiService : IPOSApiService
    {
        private readonly HttpClient _httpClient;
        private const string BaseUrl = "https://localhost:7197";

        public POSApiService(HttpClient httpClient)
        {
            _httpClient = httpClient;
            _httpClient.BaseAddress = new Uri(BaseUrl);
        }

        public async Task<IEnumerable<Product>> GetProductsAsync()
        {
            try
            {
                var response = await _httpClient.GetFromJsonAsync<IEnumerable<Product>>($"{BaseUrl}/api/Products");
                return response ?? new List<Product>();
            }
            catch (Exception ex)
            {
                // In a production environment, you would want to log this error
                Console.WriteLine($"Error fetching products: {ex.Message}");
                throw;
            }
        }

        public async Task<Sale> CreateSaleAsync(Sale sale)
        {
            try
            {
                var response = await _httpClient.PostAsJsonAsync($"{BaseUrl}/api/Sales", sale);
                response.EnsureSuccessStatusCode(); // Throws an exception if the HTTP response status code is not 2xx
                return await response.Content.ReadFromJsonAsync<Sale>();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error creating sale: {ex.Message}");
                throw;
            }
        }
    }
} 