using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Newtonsoft.Json;
using POS_UI.Models;
using POS_UI.Services;

namespace POS_UI.Pages
{
    public class NewSaleModel : PageModel
    {
        private readonly IPOSApiService _posApiService;

        public NewSaleModel(IPOSApiService posApiService)
        {
            _posApiService = posApiService;
        }

        [BindProperty]
        public string CustomerId { get; set; }

        public IEnumerable<Product> Products { get; private set; }

        [BindProperty]
        public string SaleItemsJson { get; set; } // To receive JSON string from frontend

        public string Message { get; private set; }
        public bool IsSuccess { get; private set; }

        public async Task<IActionResult> OnGetAsync()
        {
            await LoadProducts();
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            await LoadProducts(); // Ensure products are loaded at the start of POST

            if (!ModelState.IsValid)
            {
                IsSuccess = false;
                Message = "Please correct the form errors.";
                return Page();
            }

            try
            {
                Console.WriteLine($"Received SaleItemsJson: {SaleItemsJson}");
                var selectedItems = JsonConvert.DeserializeObject<List<NewSaleItemDto>>(SaleItemsJson);
                Console.WriteLine($"Deserialized {selectedItems?.Count ?? 0} items.");

                if (selectedItems == null || !selectedItems.Any())
                {
                    IsSuccess = false;
                    Message = "Please select at least one product for the sale.";
                    return Page();
                }

                // Basic validation for stock quantities. More robust validation should be on the API.
                foreach (var item in selectedItems)
                {
                    if (string.IsNullOrEmpty(item.ProductId))
                    {
                        IsSuccess = false;
                        Message = "One of the selected products has an invalid or missing Product ID.";
                        return Page();
                    }

                    var product = Products.FirstOrDefault(p => p.Id == item.ProductId);
                    if (product == null)
                    {
                        IsSuccess = false;
                        Message = $"Product with ID {item.ProductId} not found. Please refresh the page.";
                        return Page();
                    }
                    if (item.Quantity <= 0 || item.Quantity > product.StockQuantity)
                    {
                        IsSuccess = false;
                        Message = $"Invalid quantity ({item.Quantity}) for product {product.Name}. Available stock: {product.StockQuantity}.";
                        return Page();
                    }

                    Console.WriteLine($"Adding SaleItem - ProductId: {item.ProductId}, Quantity: {item.Quantity}, UnitPrice: {item.UnitPrice}, Calculated TotalPrice: {item.Quantity * item.UnitPrice}");
                }

                var sale = new Sale
                {
                    CustomerId = CustomerId,
                    SaleDate = DateTime.UtcNow,
                    Items = selectedItems.Select(item => new SaleItem
                    {
                        ProductId = item.ProductId,
                        Quantity = item.Quantity,
                        UnitPrice = item.UnitPrice,
                        TotalPrice = item.Quantity * item.UnitPrice
                    }).ToList()
                };

                Console.WriteLine($"Sale.Items count before Sum: {sale.Items.Count}");
                sale.TotalAmount = sale.Items.Sum(item => item.TotalPrice);

                Console.WriteLine("Attempting to create sale with the following details:");
                Console.WriteLine($"  CustomerId: {sale.CustomerId}");
                Console.WriteLine($"  SaleDate: {sale.SaleDate}");
                Console.WriteLine($"  TotalAmount: {sale.TotalAmount}");
                foreach (var item in sale.Items)
                {
                    Console.WriteLine($"    SaleItem: ProductId={item.ProductId}, Quantity={item.Quantity}, UnitPrice={item.UnitPrice}, TotalPrice={item.TotalPrice}");
                }

                var createdSale = await _posApiService.CreateSaleAsync(sale);

                IsSuccess = true;
                Message = $"Sale created successfully! Sale ID: {createdSale.Id}";
                // Optionally clear form or redirect
                CustomerId = string.Empty; // Clear customer ID for a new sale
                SaleItemsJson = string.Empty;
                await LoadProducts(); // Reload products to update stock if necessary
                return Page();
            }
            catch (HttpRequestException httpEx)
            {
                IsSuccess = false;
                Message = $"Failed to create sale: {httpEx.Message}. Status Code: {httpEx.StatusCode}.";
                Console.WriteLine($"Error creating sale: {httpEx.Message}. Status Code: {httpEx.StatusCode}");
            }
            catch (Exception ex)
            {
                IsSuccess = false;
                Message = "An unexpected error occurred while creating the sale.";
                Console.WriteLine($"Error creating sale: {ex.Message}\nStackTrace: {ex.StackTrace}");
            }
            return Page();
        }

        private async Task LoadProducts()
        {
            try
            {
                Products = await _posApiService.GetProductsAsync();
            }
            catch (Exception ex)
            {
                // Log this, but don't prevent the page from loading
                Console.WriteLine($"Error loading products for new sale page: {ex.Message}");
                Products = new List<Product>();
                Message = "Could not load products for sale creation.";
                IsSuccess = false;
            }
        }
    }

    // DTO for receiving selected product data from JavaScript
    public class NewSaleItemDto
    {
        public string ProductId { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public int StockQuantity { get; set; } // For client-side validation
    }
} 