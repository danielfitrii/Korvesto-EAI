using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using POS_UI.Models;
using POS_UI.Services;

namespace POS_UI.Pages
{
    public class ProductsModel : PageModel
    {
        private readonly IPOSApiService _posApiService;

        public ProductsModel(IPOSApiService posApiService)
        {
            _posApiService = posApiService;
        }

        public IEnumerable<Product> Products { get; private set; }
        public string ErrorMessage { get; private set; }

        public async Task<IActionResult> OnGetAsync()
        {
            try
            {
                Products = await _posApiService.GetProductsAsync();
                return Page();
            }
            catch (HttpRequestException httpEx)
            {
                ErrorMessage = $"Failed to load products: {httpEx.Message}. Status Code: {httpEx.StatusCode}.";
                Console.WriteLine($"Error fetching products: {httpEx.Message}. Status Code: {httpEx.StatusCode}");
                Products = new List<Product>();
                return Page();
            }
            catch (Exception ex)
            {
                ErrorMessage = "An unexpected error occurred while loading products. Please try again later.";
                Console.WriteLine($"Error fetching products: {ex.Message}");
                Products = new List<Product>();
                return Page();
            }
        }
    }
} 